
 const Data = ()=>[
    {
      name: "Bortie Yaks",
      age: "29 years",
      img: "https://randomuser.me/api/portraits/women/36.jpg",
    },
    {
      name: "Hester Hogan",
      age: "32 years",
      img: "https://randomuser.me/api/portraits/women/34.jpg",
    },
    {
      name: "Larry Little",
      age: "36 years",
      img: "https://randomuser.me/api/portraits/men/66.jpg",
    },
    {
      name: "Scan Walsh",
      age: "34 years",
      img: "https://randomuser.me/api/portraits/men/0.jpg",
    },
    {
      name: "Lota Gardner",
      age: "34 years",
      img: "https://randomuser.me/api/portraits/women/32.jpg",
    },
  ];
  export default Data